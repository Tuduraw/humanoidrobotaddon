package com.example.humanoidrobotaddon.network;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: this tick's FLIGHT yaw/pitch input (arrow keys, plus the mouse for
 * flight_style "aircraft"). Roll rides the base mod's synced sideways input. Sent as a magnitude;
 * the receiver clamps to the configured per-tick rate, so held keys simply saturate it. */
public record RobotOrientationInputPayload(float yawDelta, float pitchDelta) implements class_8710 {

	public static final class_8710.class_9154<RobotOrientationInputPayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(HumanoidRobotAddon.MOD_ID, "orientation_input"));

	public static final class_9139<class_9129, RobotOrientationInputPayload> CODEC = class_9139.method_56435(
			class_9135.field_48552, RobotOrientationInputPayload::yawDelta,
			class_9135.field_48552, RobotOrientationInputPayload::pitchDelta,
			RobotOrientationInputPayload::new
	);

	@Override
	public class_8710.class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
