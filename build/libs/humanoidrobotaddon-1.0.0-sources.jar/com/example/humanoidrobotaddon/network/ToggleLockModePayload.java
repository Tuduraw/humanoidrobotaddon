package com.example.humanoidrobotaddon.network;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Client -> server: the pilot pressed the lock-mode key - switch the SELECTED weapon between
 * multi-target and single-target (focus) mode, if it is a multi_lock weapon (see HumanoidRobotEntity's
 * own tudursvehiclemod$toggleLockFocus()). No fields: the server resolves which weapon from its own
 * synced weapon selection. */
public record ToggleLockModePayload() implements class_8710 {

	public static final class_8710.class_9154<ToggleLockModePayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(HumanoidRobotAddon.MOD_ID, "toggle_lock_mode"));

	public static final class_9139<class_9129, ToggleLockModePayload> CODEC =
			class_9139.method_56431(new ToggleLockModePayload());

	@Override
	public class_8710.class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
