package com.example.humanoidrobotaddon.network;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: the mode key was pressed (short or long). Carries only the kind of press;
 * the server resolves it against the robot's current mode (HumanoidRobotEntity.applyModeKey()),
 * so a client can't name an arbitrary mode. */
public record SetMovementModePayload(boolean longPress) implements class_8710 {

	public static final class_8710.class_9154<SetMovementModePayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(HumanoidRobotAddon.MOD_ID, "set_movement_mode"));

	public static final class_9139<class_9129, SetMovementModePayload> CODEC = class_9139.method_56434(
			class_9135.field_48547, SetMovementModePayload::longPress,
			SetMovementModePayload::new
	);

	@Override
	public class_8710.class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
