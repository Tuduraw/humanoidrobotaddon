package com.example.humanoidrobotaddon.network;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server, every FLIGHT tick: the pilot's head-look offset (HeadLookOffsetState), so
 * candidate search can use the camera's actual direction - the head-look never touches the pilot's
 * stored yaw/pitch, so getRotationVec() would be unrelated to what the camera shows. */
public record RobotHeadLookPayload(float yaw, float pitch) implements class_8710 {

	public static final class_8710.class_9154<RobotHeadLookPayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(HumanoidRobotAddon.MOD_ID, "head_look"));

	public static final class_9139<class_9129, RobotHeadLookPayload> CODEC = class_9139.method_56435(
			class_9135.field_48552, RobotHeadLookPayload::yaw,
			class_9135.field_48552, RobotHeadLookPayload::pitch,
			RobotHeadLookPayload::new
	);

	@Override
	public class_8710.class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
