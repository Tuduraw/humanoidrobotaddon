package com.example.humanoidrobotaddon.item;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import com.example.tudursvehiclemod.item.TieredVehicleSpawnerItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/** This addon's own items - the base mod's own TieredVehicleSpawnerItem, not a bespoke one, so
 * right-clicking a spawner opens the base mod's own vehicle selection screen filtered to robots of
 * that tier or below, with no screen or networking code here. */
public class RobotItems {

	/** [tier - 1]. Handed to the base mod's converter through RobotConverterTarget. */
	public static final class_1792[] ROBOT_SPAWNERS = new class_1792[5];

	public static final RobotConverterTarget TARGET = new RobotConverterTarget("humanoid_robot", ROBOT_SPAWNERS);

	public static void register() {
		registerSpawners("humanoid_robot", TARGET, ROBOT_SPAWNERS);

		class_5321<class_1761> groupKey =
				class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(HumanoidRobotAddon.MOD_ID, "humanoid_robots"));
		class_2378.method_39197(class_7923.field_44687, groupKey, FabricItemGroup.builder()
				.method_47320(() -> new class_1799(ROBOT_SPAWNERS[0]))
				.method_47321(class_2561.method_43471("itemGroup.humanoidrobotaddon.humanoid_robots"))
				.method_47324());

		ItemGroupEvents.modifyEntriesEvent(groupKey).register(entries -> {
			for (class_1792 item : ROBOT_SPAWNERS) {
				entries.method_45421(item);
			}
		});
	}

	private static void registerSpawners(String category, RobotConverterTarget target, class_1792[] into) {
		for (int tier = 1; tier <= 5; tier++) {
			String path = category + "_spawner_t" + tier;
			class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(HumanoidRobotAddon.MOD_ID, path));
			class_1792 item = new TieredVehicleSpawnerItem(
					new class_1792.class_1793().method_63686(key).method_7889(1), target, tier);
			into[tier - 1] = class_2378.method_39197(class_7923.field_41178, key, item);
		}
	}
}
