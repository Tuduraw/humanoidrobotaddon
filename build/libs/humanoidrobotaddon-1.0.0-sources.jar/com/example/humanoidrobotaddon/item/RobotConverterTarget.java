package com.example.humanoidrobotaddon.item;

import com.example.humanoidrobotaddon.HumanoidRobotAddon;
import com.example.tudursvehiclemod.item.VehicleConverterTarget;
import net.minecraft.class_1792;
import net.minecraft.class_2960;

/** Opts the humanoid robot into the base mod's own tiered base item -> spawner item converter, and
 * into packing a placed robot back up into a spawner item.
 *
 * <p>Registering this is entirely optional - an addon wanting a costlier, independent way of
 * obtaining its vehicles simply never registers a target. */
/** One base-mod converter/spawner category per robot entity type (the base mod matches a vehicle
 * JSON's own entity_type against exactly one category). */
public class RobotConverterTarget implements VehicleConverterTarget {

	private final String category;
	private final class_1792[] spawners;

	public RobotConverterTarget(String category, class_1792[] spawners) {
		this.category = category;
		this.spawners = spawners;
	}

	@Override
	public class_2960 entityTypeId() {
		return class_2960.method_60655(HumanoidRobotAddon.MOD_ID, this.category);
	}

	@Override
	public String translationKey() {
		return "item.humanoidrobotaddon.category." + this.category;
	}

	@Override
	public class_2960 id() {
		return class_2960.method_60655(HumanoidRobotAddon.MOD_ID, this.category);
	}

	@Override
	public class_1792[] tieredSpawnerItems() {
		return this.spawners;
	}
}
