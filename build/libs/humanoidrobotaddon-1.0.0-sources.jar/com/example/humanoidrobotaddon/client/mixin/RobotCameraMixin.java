package com.example.humanoidrobotaddon.client.mixin;

import com.example.humanoidrobotaddon.client.HeadLookOffsetState;
import com.example.humanoidrobotaddon.entity.HumanoidRobotEntity;
import com.example.tudursvehiclemod.client.AircraftCameraZoomState;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Camera for a HumanoidRobotEntity in FLIGHT (flight_style "robot"): free mouse-look AND smooth
 * body-following at once, which neither branch of the base mod's own CameraMixin gives (locked =
 * follows but no mouse; free-look = mouse but no yaw/pitch following). Recomputed every render
 * frame as body orientation x head-look offset, both as quaternions - no per-tick carry-over
 * (visible stepping at flight rotation rates) and no Euler round-trip.
 *
 * <p>Priority above the default 1000 so it runs after the base mod's CameraMixin at the same TAIL
 * and its write is the one that sticks. Stands aside for the "aircraft" scheme, ground modes and
 * every other vehicle. See DEVELOPMENT_NOTES.md. */
@Mixin(value = class_4184.class, priority = 2000)
public abstract class RobotCameraMixin {

	@Invoker("setPos")
	public abstract void tudursvehiclemod$setPos(class_243 pos);

	@Inject(method = "update(Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;ZZF)V", at = @At("TAIL"))
	private void tudursvehiclemod$applyRobotFlightCamera(class_1937 area, class_1297 focusedEntity, boolean thirdPerson,
														  boolean inverseView, float tickProgress, CallbackInfo ci) {
		if (!(focusedEntity instanceof class_1657 player)) {
			return;
		}
		if (!(player.method_5854() instanceof HumanoidRobotEntity robot)) {
			return;
		}
		if (!robot.tudursvehiclemod$getMovementMode().flies()) {
			return;
		}
		if (robot.tudursvehiclemod$usesAircraftFlightControls()) {
			return; // aircraft-style: the base mod's own CameraMixin (locked / free-look) drives it
		}

		class_4184 self = (class_4184) (Object) this;
		class_243 eyePos = robot.getRotatedEyePos(player, tickProgress);

		// The base mod's own camera-space construction for a locked FreeCameraVehicle, with the
		// head-look composed on top as a local rotation.
		float yaw = robot.method_5705(tickProgress);
		float pitch = robot.method_5695(tickProgress);
		float roll = robot.getRoll(tickProgress);

		Quaternionf fresh = new Quaternionf();
		fresh.rotateY((float) Math.toRadians(180.0 - yaw));
		fresh.rotateX((float) Math.toRadians(-pitch));
		fresh.rotateZ((float) Math.toRadians(-roll));
		if (inverseView) {
			fresh.rotateY((float) Math.PI);
		}
		// Built fresh from two independent scalars (Ry then Rx) - accumulating a quaternion drifts
		// into roll.
		Quaternionf headOffset = new Quaternionf()
				.rotationY((float) Math.toRadians(HeadLookOffsetState.yaw))
				.rotateX((float) Math.toRadians(HeadLookOffsetState.pitch));
		fresh.mul(headOffset);
		self.method_23767().set(fresh);

		if (thirdPerson) {
			// Pull direction from the same `fresh` quaternion: local +Z is the vehicle's forward, so
			// this is correct for both the behind and the front (inverseView) stage. Deriving it from a
			// separately-built quaternion diverges once head-look is composed in (non-commutative).
			Vector3f pullDirection = new Vector3f(0, 0, 1);
			fresh.transform(pullDirection);
			this.tudursvehiclemod$setPos(tudursvehiclemod$pullBack(area, player, eyePos, pullDirection));
		} else {
			this.tudursvehiclemod$setPos(eyePos);
		}
	}

	/** Ported from the base mod's own CameraMixin (a private method there, not reachable from this
	 * separate mixin class) - pulls the camera away from eyePos along pullDirection by
	 * AircraftCameraZoomState's own current scroll-wheel zoom distance, clamped by a raycast so it
	 * doesn't clip through terrain. */
	private static class_243 tudursvehiclemod$pullBack(class_1937 area, class_1657 player, class_243 eyePos, Vector3f pullDirection) {
		double desiredDistance = AircraftCameraZoomState.currentDistance;
		class_243 desiredPos = new class_243(
				eyePos.field_1352 + pullDirection.x * desiredDistance,
				eyePos.field_1351 + pullDirection.y * desiredDistance,
				eyePos.field_1350 + pullDirection.z * desiredDistance);

		double actualDistance = desiredDistance;
		class_3959 raycastContext = new class_3959(eyePos, desiredPos,
				class_3959.class_3960.field_23142, class_3959.class_242.field_1348, player);
		class_3965 hit = area.method_17742(raycastContext);
		if (hit.method_17783() == class_239.class_240.field_1332) {
			double hitDistance = eyePos.method_1022(hit.method_17784());
			actualDistance = Math.max(0.0, Math.min(desiredDistance, hitDistance - 0.25));
		}

		return new class_243(
				eyePos.field_1352 + pullDirection.x * actualDistance,
				eyePos.field_1351 + pullDirection.y * actualDistance,
				eyePos.field_1350 + pullDirection.z * actualDistance);
	}
}
