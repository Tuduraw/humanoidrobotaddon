package com.example.humanoidrobotaddon.client;

import com.example.humanoidrobotaddon.entity.HumanoidRobotEntity;
import com.example.tudursvehiclemod.asset.ServerObjModelHitboxes;
import com.example.tudursvehiclemod.asset.VehicleDefinition;
import com.example.tudursvehiclemod.asset.WeaponDefinition;
import com.example.tudursvehiclemod.entity.AbstractVehicleEntity;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;

/** This addon's own in-world markers: the candidate preview (orange, pilot only) and every locked
 * target (red + the locking weapon names, "name i/n" for multi-lock). Drawn with GizmoDrawing rather
 * than the base mod's shared highlight state, which its own missile lock-on also switches and would
 * fight over the same on/off flag.
 *
 * <p>A vehicle target is outlined by its own mesh (decimated above MAX_TRIANGLES_PER_DRAW), same
 * technique and cap as the base mod's own TargetHighlightRenderer, since a vehicle's hitbox is
 * deliberately larger than its visible model. Anything else uses its bounding box. */
public final class LockMarkerRenderer {

	private LockMarkerRenderer() {
	}

	private static final int LOCK_COLOR = 0xFFFF3030;
	private static final int CANDIDATE_COLOR = 0xFFFF9010;
	private static final float LINE_WIDTH = 2.0f;
	private static final float LABEL_SCALE = 1.0f;
	private static final int MAX_TRIANGLES_PER_DRAW = 400;

	/** Once per client tick: draws the markers for every loaded HumanoidRobotEntity. */
	public static void tick(class_310 client) {
		if (client.field_1687 == null) {
			return;
		}

		try (var scope = client.method_75308()) {
			for (class_1297 entity : client.field_1687.method_18112()) {
				if (!(entity instanceof HumanoidRobotEntity robot)) {
					continue;
				}
				// Candidate preview: this addon's own outline (not the base mod's shared highlight
				// state, which its own missile lock-on also switches). Shown only to the pilot.
				if (robot.method_5642() == client.field_1724
						&& robot.tudursvehiclemod$settings().highlightTarget()) {
					class_1297 candidate = robot.tudursvehiclemod$getCandidate();
					if (candidate != null) {
						tudursvehiclemod$outline(candidate, CANDIDATE_COLOR);
					}
				}
				Map<class_1297, List<String>> weaponNamesByTarget = tudursvehiclemod$collectLocks(robot);
				for (Map.Entry<class_1297, List<String>> entry : weaponNamesByTarget.entrySet()) {
					class_1297 target = entry.getKey();
					tudursvehiclemod$outline(target, LOCK_COLOR);
					class_12180.method_75540(target, 0, String.join(", ", entry.getValue()), LOCK_COLOR, LABEL_SCALE);
				}
			}
		}
	}

	/** One robot's locked entities keyed by target (a target may be locked by several weapons), each
	 * with its weapon labels. weaponName() (the .txt file name), not displayName(), which falls back
	 * to "Weapon" when the file is missing. */
	private static Map<class_1297, List<String>> tudursvehiclemod$collectLocks(HumanoidRobotEntity robot) {
		Map<class_1297, List<String>> byTarget = new LinkedHashMap<>();
		for (Map.Entry<Integer, List<Integer>> lock : robot.tudursvehiclemod$getAllLockLists().entrySet()) {
			int seatIndex = lock.getKey();
			WeaponDefinition weapon = robot.tudursvehiclemod$weaponForSeat(seatIndex);
			String name = weapon != null ? weapon.weaponName() : ("#" + seatIndex);
			List<Integer> ids = lock.getValue();
			boolean multi = robot.tudursvehiclemod$isMultiLockActive(seatIndex);
			for (int i = 0; i < ids.size(); i++) {
				class_1297 target = robot.method_73183().method_8469(ids.get(i));
				if (target == null) {
					continue;
				}
				String label = multi ? name + " " + (i + 1) + "/" + ids.size() : name;
				byTarget.computeIfAbsent(target, t -> new ArrayList<>()).add(label);
			}
		}
		return byTarget;
	}

	/** Mesh outline for a vehicle (its hitbox is oversized for collision, not its visible shape -
	 * matching TargetHighlightRenderer's own reasoning); bounding box for anything else. */
	private static void tudursvehiclemod$outline(class_1297 target, int color) {
		if (target instanceof AbstractVehicleEntity vehicle) {
			VehicleDefinition def = vehicle.getDefinition();
			Optional<ServerObjModelHitboxes.Mesh> mesh = ServerObjModelHitboxes.getMesh(def.model());
			if (mesh.isPresent()) {
				tudursvehiclemod$drawMesh(vehicle, def, mesh.get(), color);
				return;
			}
		}
		class_12180.method_75541(target.method_5829(), class_12179.method_75536(color, LINE_WIDTH));
	}

	private static void tudursvehiclemod$drawMesh(AbstractVehicleEntity vehicle, VehicleDefinition def,
			ServerObjModelHitboxes.Mesh mesh, int color) {
		Quaternionf rotation = vehicle.tudursvehiclemod$getCurrentRotationForRendering();
		float scale = def.scale();
		double x = vehicle.method_23317();
		double y = vehicle.method_23318();
		double z = vehicle.method_23321();
		for (float[] tri : tudursvehiclemod$sampleTriangles(mesh.triangles())) {
			class_243 a = tudursvehiclemod$toWorld(tri[0], tri[1], tri[2], rotation, scale, x, y, z);
			class_243 b = tudursvehiclemod$toWorld(tri[3], tri[4], tri[5], rotation, scale, x, y, z);
			class_243 c = tudursvehiclemod$toWorld(tri[6], tri[7], tri[8], rotation, scale, x, y, z);
			class_12180.method_75546(a, b, color, LINE_WIDTH);
			class_12180.method_75546(b, c, color, LINE_WIDTH);
			class_12180.method_75546(c, a, color, LINE_WIDTH);
		}
	}

	/** Evenly-strided subsampling above the cap, matching TargetHighlightRenderer's own
	 * MAX_TRIANGLES_PER_DRAW - a coarse outline covering the whole model, not just one end of the
	 * triangle list. */
	private static List<float[]> tudursvehiclemod$sampleTriangles(List<float[]> triangles) {
		if (triangles.size() <= MAX_TRIANGLES_PER_DRAW) {
			return triangles;
		}
		List<float[]> sampled = new ArrayList<>(MAX_TRIANGLES_PER_DRAW);
		float stride = (float) triangles.size() / MAX_TRIANGLES_PER_DRAW;
		for (int i = 0; i < MAX_TRIANGLES_PER_DRAW; i++) {
			sampled.add(triangles.get((int) (i * stride)));
		}
		return sampled;
	}

	private static class_243 tudursvehiclemod$toWorld(float localX, float localY, float localZ,
			Quaternionf rotation, float scale, double vehicleX, double vehicleY, double vehicleZ) {
		Vector3f local = new Vector3f(localX * scale, localY * scale, localZ * scale);
		rotation.transform(local);
		return new class_243(vehicleX + local.x, vehicleY + local.y, vehicleZ + local.z);
	}
}
